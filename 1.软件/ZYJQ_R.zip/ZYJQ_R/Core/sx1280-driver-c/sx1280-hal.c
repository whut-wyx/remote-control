/*
  ______                              _
 / _____)             _              | |
( (____  _____ ____ _| |_ _____  ____| |__
 \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 _____) ) ____| | | || |_| ____( (___| | | |
(______/|_____)_|_|_| \__)_____)\____)_| |_|
    (C)2016 Semtech

Description: Handling of the node configuration protocol

License: Revised BSD License, see LICENSE.TXT file include in the project

Maintainer: Miguel Luis, Matthieu Verdy and Benjamin Boulet
*/
//#include "hw.h"
#include <stdio.h>
#include <string.h>
#include "sx1280-hal.h"
#include "radio.h"
#include "main.h"
#include "spi.h"
#include "hw-gpio.h"
#include "userFun.h"
/*!
 * \brief Define the size of tx and rx hal buffers
 *
 * The Tx and Rx hal buffers are used for SPI communication to
 * store data to be sent/receive to/from the chip.
 *
 * \warning The application must ensure the maximal useful size to be much lower
 *          than the MAX_HAL_BUFFER_SIZE
 */
#define MAX_HAL_BUFFER_SIZE   0xFFF

#define IRQ_HIGH_PRIORITY  0

HAL_StatusTypeDef HAL_SPIEx_FlushRxFifo(SPI_HandleTypeDef *hspi)
{
  __IO uint32_t tmpreg;
  //uint8_t  count = 0U;
  //while ((hspi->Instance->SR & SPI_FLAG_FRLVL) !=  SPI_FRLVL_EMPTY)
  //{
  //  count++;
    tmpreg = hspi->Instance->DR;
    UNUSED(tmpreg); /* To avoid GCC warning */
   // if (count == SPI_FIFO_SIZE)
   // {
   //   return HAL_TIMEOUT;
   // }
  //}
	return HAL_OK;
}
/*!
 * Radio driver structure initialization
 */
const struct Radio_s Radio =
{
    SX1280Init,
    SX1280HalReset,
    SX1280GetStatus,
    SX1280HalWriteCommand,
    SX1280HalReadCommand,
    SX1280HalWriteRegisters,
    SX1280HalWriteRegister,
    SX1280HalReadRegisters,
    SX1280HalReadRegister,
    SX1280HalWriteBuffer,
    SX1280HalReadBuffer,
    SX1280HalGetDioStatus,
    SX1280GetFirmwareVersion,
    SX1280SetRegulatorMode,
    SX1280SetStandby,
    SX1280SetPacketType,
    SX1280SetModulationParams,
    SX1280SetPacketParams,
    SX1280SetRfFrequency,
    SX1280SetBufferBaseAddresses,
    SX1280SetTxParams,
    SX1280SetDioIrqParams,
    SX1280SetSyncWord,
    SX1280SetRx,
    SX1280GetPayload,
    SX1280SendPayload,
    SX1280SetRangingRole,
    SX1280SetPollingMode,
    SX1280SetInterruptMode,
    SX1280SetRegistersDefault,
    SX1280GetOpMode,
    SX1280SetSleep,
    SX1280SetFs,
    SX1280SetTx,
    SX1280SetRxDutyCycle,
    SX1280SetCad,
    SX1280SetTxContinuousWave,
    SX1280SetTxContinuousPreamble,
    SX1280GetPacketType,
    SX1280SetCadParams,
    SX1280GetRxBufferStatus,
    SX1280GetPacketStatus,
    SX1280GetRssiInst,
    SX1280GetIrqStatus,
    SX1280ClearIrqStatus,
    SX1280Calibrate,
    SX1280SetSaveContext,
    SX1280SetAutoTx,
    SX1280StopAutoTx,
    SX1280SetAutoFS,
    SX1280SetLongPreamble,
    SX1280SetPayload,
    SX1280SetSyncWordErrorTolerance,
    SX1280SetCrcSeed,
    SX1280SetBleAccessAddress,
    SX1280SetBleAdvertizerAccessAddress,
    SX1280SetCrcPolynomial,
    SX1280SetWhiteningSeed,
    SX1280EnableManualGain,
    SX1280DisableManualGain,
    SX1280SetManualGainValue,
    SX1280SetLNAGainSetting,
    SX1280SetRangingIdLength,
    SX1280SetDeviceRangingAddress,
    SX1280SetRangingRequestAddress,
    SX1280GetRangingResult,
    SX1280SetRangingCalibration,
    SX1280GetRangingPowerDeltaThresholdIndicator,
    SX1280RangingClearFilterResult,
    SX1280RangingSetFilterNumSamples,
    SX1280GetFrequencyError,
};

static uint8_t halTxBuffer[MAX_HAL_BUFFER_SIZE] = {0x00};
static uint8_t halRxBuffer[MAX_HAL_BUFFER_SIZE] = {0x00};

/*!
 * \brief Used to block execution waiting for low state on radio busy pin.
 *        Essentially used in SPI communications
 */

uint8_t SX1280_SimSendByte( uint8_t output )
{
    uint8_t i;
    uint8_t temp;
    uint8_t input = 0;

    for (i=0; i<8; i++)  //8λ
    {
        if (output & 0x80u)  // 1
        {
            HAL_GPIO_WritePin( GPIOB, GPIO_PIN_15, GPIO_PIN_SET ) ;//SPI2_MOSI
        }
        else  //0
        {
            HAL_GPIO_WritePin( GPIOB, GPIO_PIN_15, GPIO_PIN_RESET ) ;
        }
        output <<= 1 ;

        delay_us(1) ;

        HAL_GPIO_WritePin( GPIOB, GPIO_PIN_13, GPIO_PIN_SET ) ; //SPI2_SCK
        delay_us(1) ;

        input <<= 1 ;
        temp = HAL_GPIO_ReadPin( GPIOB, GPIO_PIN_14 ); //SPI2_MISO
        if(temp)
        {
            input = input | 0x01 ;
        }
//				else
//					input = input & 0xfe ;

        HAL_GPIO_WritePin( GPIOB, GPIO_PIN_13, GPIO_PIN_RESET ) ;
    }

    return input ;
}


void SpiIn( uint8_t *txBuffer, uint16_t size )
{
//    uint16_t i ;

//    for( i = 0 ; i < size ; i ++ )
//    {
//        SX1280_SimSendByte( txBuffer[i] ) ;
//        // SPIWrite8bit( txBuffer[i] ) ;
//    }
		//while(hspi2.State != HAL_SPI_STATE_BUSY_TX)//��������ٷ�
		
		//HAL_SPIEx_FlushRxFifo(&hspi2);
		HAL_SPI_Transmit( &hspi2, txBuffer, size, HAL_MAX_DELAY );
}


void SpiInOut( uint8_t *txBuffer, uint8_t *rxBuffer, uint16_t size )
{
//    uint16_t i ;

//    for ( i = 0 ; i < size ; i ++ )
//    {
//        rxBuffer[i] = SX1280_SimSendByte( txBuffer[i] ) ;
//        // rxBuffer[i] = SPIRead8bit( txBuffer[i] ) ;
//    }
		//while(hspi2.State != HAL_SPI_STATE_BUSY_TX)
		//HAL_SPIEx_FlushRxFifo(&hspi2);
		HAL_SPI_TransmitReceive( &hspi2, txBuffer, rxBuffer, size, HAL_MAX_DELAY );
		//HAL_SPIEx_FlushRxFifo(&hspi2);
}

void SX1280HalWaitOnBusy( void )
{
    while( HAL_GPIO_ReadPin( BUSY_GPIO_Port, BUSY_Pin ) == 1 );
}

void SX1280HalInit( DioIrqHandler **irqHandlers )
{
    SX1280HalReset( );
    SX1280HalIoIrqInit( irqHandlers );
}


void SX1280HalIoIrqInit( DioIrqHandler **irqHandlers )
{
#if( RADIO_DIO1_ENABLE )
    //GpioSetIrq(DIO1_GPIO_Port, DIO1_Pin, IRQ_HIGH_PRIORITY, irqHandlers[0]);
#endif
#if( RADIO_DIO2_ENABLE )
	GpioSetIrq( RADIO_DIO2_GPIO_Port, RADIO_DIO2_Pin, IRQ_HIGH_PRIORITY, irqHandlers[0] );
#endif
#if( RADIO_DIO3_ENABLE )
	GpioSetIrq( RADIO_DIO3_GPIO_Port, RADIO_DIO3_Pin, IRQ_HIGH_PRIORITY, irqHandlers[0] );
#endif
#if( !RADIO_DIO1_ENABLE && !RADIO_DIO2_ENABLE && !RADIO_DIO3_ENABLE )
#error "Please define a DIO" 
#endif
}

void SX1280HalReset( void )
{
    HAL_Delay( 20 );
    HAL_GPIO_WritePin( NRESET_GPIO_Port, NRESET_Pin, GPIO_PIN_RESET);
    HAL_Delay( 100 );
    HAL_GPIO_WritePin( NRESET_GPIO_Port, NRESET_Pin, GPIO_PIN_SET );
    HAL_Delay( 20 );
}

void SX1280HalClearInstructionRam( void )
{
    // Clearing the instruction RAM is writing 0x00s on every bytes of the
    // instruction RAM
    uint16_t halSize = 3 + IRAM_SIZE;
    halTxBuffer[0] = RADIO_WRITE_REGISTER;
    halTxBuffer[1] = ( IRAM_START_ADDRESS >> 8 ) & 0x00FF;
    halTxBuffer[2] = IRAM_START_ADDRESS & 0x00FF;
    for( uint16_t index = 0; index < IRAM_SIZE; index++ )
    {
        halTxBuffer[3+index] = 0x00;
    }

    SX1280HalWaitOnBusy( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);

    SpiIn( halTxBuffer, halSize );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    SX1280HalWaitOnBusy( );
}

void SX1280HalWakeup( void )
{
    __disable_irq( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);

    uint16_t halSize = 2;
    halTxBuffer[0] = RADIO_GET_STATUS;
    halTxBuffer[1] = 0x00;
    SpiIn( halTxBuffer, halSize );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    // Wait for chip to be ready.
    SX1280HalWaitOnBusy( );

    __enable_irq( );
}

void SX1280HalWriteCommand( RadioCommands_t command, uint8_t *buffer, uint16_t size )
{
    uint16_t halSize  = size + 1;
    SX1280HalWaitOnBusy( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);

    halTxBuffer[0] = command;
    memcpy( halTxBuffer + 1, ( uint8_t * )buffer, size * sizeof( uint8_t ) );

    SpiIn( halTxBuffer, halSize );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    if( command != RADIO_SET_SLEEP )
    {
        SX1280HalWaitOnBusy( );
    }
}

void SX1280HalReadCommand( RadioCommands_t command, uint8_t *buffer, uint16_t size )
{
    uint16_t halSize = 2 + size;
    halTxBuffer[0] = command;
    halTxBuffer[1] = 0x00;
    for( uint16_t index = 0; index < size; index++ )
    {
        halTxBuffer[2+index] = 0x00;
    }

    SX1280HalWaitOnBusy( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);
		
		//HAL_SPIEx_FlushRxFifo(&hspi2);
    //HAL_SPI_TransmitReceive( &hspi2, halTxBuffer, halRxBuffer, halSize, HAL_MAX_DELAY );
		SpiInOut(halTxBuffer, halRxBuffer, halSize);
		
    memcpy( buffer, halRxBuffer + 2, size );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    SX1280HalWaitOnBusy( );
}

void SX1280HalWriteRegisters( uint16_t address, uint8_t *buffer, uint16_t size )
{
    uint16_t halSize = size + 3;
    halTxBuffer[0] = RADIO_WRITE_REGISTER;
    halTxBuffer[1] = ( address & 0xFF00 ) >> 8;
    halTxBuffer[2] = address & 0x00FF;
    memcpy( halTxBuffer + 3, buffer, size );

    SX1280HalWaitOnBusy( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);

    SpiIn( halTxBuffer, halSize );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    SX1280HalWaitOnBusy( );
}

void SX1280HalWriteRegister( uint16_t address, uint8_t value )
{
    SX1280HalWriteRegisters( address, &value, 1 );
}

void SX1280HalReadRegisters( uint16_t address, uint8_t *buffer, uint16_t size )
{
    uint16_t halSize = 4 + size;
    halTxBuffer[0] = RADIO_READ_REGISTER;
    halTxBuffer[1] = ( address & 0xFF00 ) >> 8;
    halTxBuffer[2] = address & 0x00FF;
    halTxBuffer[3] = 0x00;
    for( uint16_t index = 0; index < size; index++ )
    {
        halTxBuffer[4+index] = 0x00;
    }

    SX1280HalWaitOnBusy( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);
		
		//HAL_SPIEx_FlushRxFifo(&hspi2);
    SpiInOut( halTxBuffer, halRxBuffer, halSize );
		//HAL_SPI_TransmitReceive( &hspi2, halTxBuffer, halRxBuffer, halSize, HAL_MAX_DELAY );
    memcpy( buffer, halRxBuffer + 4, size );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    SX1280HalWaitOnBusy( );
}

uint8_t SX1280HalReadRegister( uint16_t address )
{
    uint8_t data;

    SX1280HalReadRegisters( address, &data, 1 );

    return data;
}

void SX1280HalWriteBuffer( uint8_t offset, uint8_t *buffer, uint8_t size )
{
    uint16_t halSize = size + 2;
    halTxBuffer[0] = RADIO_WRITE_BUFFER;
    halTxBuffer[1] = offset;
    memcpy( halTxBuffer + 2, buffer, size );

    SX1280HalWaitOnBusy( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);
		
    SpiIn( halTxBuffer, halSize );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    SX1280HalWaitOnBusy( );
}

void SX1280HalReadBuffer( uint8_t offset, uint8_t *buffer, uint8_t size )
{
    uint16_t halSize = size + 3;
    halTxBuffer[0] = RADIO_READ_BUFFER;
    halTxBuffer[1] = offset;
    halTxBuffer[2] = 0x00;
    for( uint16_t index = 0; index < size; index++ )
    {
        halTxBuffer[3+index] = 0x00;
    }

    SX1280HalWaitOnBusy( );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_RESET);
		
		//HAL_SPIEx_FlushRxFifo(&hspi2);
    SpiInOut( halTxBuffer, halRxBuffer, halSize );

    memcpy( buffer, halRxBuffer + 3, size );

    HAL_GPIO_WritePin( NSS_GPIO_Port, NSS_Pin, GPIO_PIN_SET);

    SX1280HalWaitOnBusy( );
}

uint8_t SX1280HalGetDioStatus( void )
{
	uint8_t Status = HAL_GPIO_ReadPin( BUSY_GPIO_Port, BUSY_Pin );
	
#if( RADIO_DIO1_ENABLE )
	Status |= (HAL_GPIO_ReadPin( DIO1_GPIO_Port, DIO1_Pin ) << 1);
#endif
#if( RADIO_DIO2_ENABLE )
	Status |= (HAL_GPIO_ReadPin( RADIO_DIO2_GPIO_Port, RADIO_DIO2_Pin ) << 2);
#endif
#if( RADIO_DIO3_ENABLE )
	Status |= (HAL_GPIO_ReadPin( RADIO_DIO3_GPIO_Port, RADIO_DIO3_Pin ) << 3);
#endif
#if( !RADIO_DIO1_ENABLE && !RADIO_DIO2_ENABLE && !RADIO_DIO3_ENABLE )
#error "Please define a DIO" 
#endif
	
	return Status;
}

uint8_t buffer[4];

void write_read_buffer(uint8_t* rbuffer)
{
	buffer[0] = 0x12;
	buffer[1] = 0x34;
	buffer[2] = 0x56;
	buffer[3] = 0x78;
	SX1280HalWriteBuffer( 0x00, buffer, 4 );
	delay_us(4);
	SX1280HalReadBuffer( 0x00, rbuffer, 4 );
}