#include "userFun.h"
#include "main.h"
#include "tim.h"
#include "inv_mpu.h"
#include "mpu6050.h"
#include "radio.h"
#include "adc.h"
#include "demoRanging.h"
//#include "pingpong.h"

#define LORA_ENTITY		SLAVE   //0
//0~10000 0~5V 3kmh��2.6679V 1kmh��1.6807V
//����̨����
#define SPEED_H_CCR	2600
#define SPEED_L_CCR	1700
#define DAMP_CNT		5
//������
#define ACC_COEFICIENT 		5
#define TURN_COEFICIENT		7
BOOL HS_flag=FALSE;
BOOL LS_flag=FALSE;
BOOL PAUSE_flag = FALSE;
BOOL BACK_S_flag = FALSE;
BOOL TURN_L_flag = FALSE;
BOOL TURN_R_flag = FALSE;
extern BOOL connect_flag;

lora_message_ts lora_message_t;
lora_message_rs lora_message_r;
pid_s pid1;
pid_s pid2;
static DemoResult_t *demoResult;

//����ٶȲɼ�
uint32_t M1_capture_value1;
uint32_t M1_capture_value2;
uint32_t M2_capture_value1;
uint32_t M2_capture_value2;
short M1_speed;
short M2_speed;
uint16_t speed_last = 0;
uint16_t pulse1_last = 0;
uint16_t pulse2_last = 0;

uint8_t count = 0;
//uint32_t count1=0;
BOOL capture1_flag=FALSE;
BOOL capture2_flag=FALSE;
BOOL signal1_flag=FALSE;
BOOL signal2_flag=FALSE;
uint32_t update1_cnt=0;
uint32_t update2_cnt=0;

//uint16_t speed1_cnt = 0;
//uint16_t speed2_cnt = 0;
//adc���ݲɼ�
extern BOOL TIM4_flag;
uint16_t adc_value[10]={0};
uint8_t adc_count;
uint16_t Vadc_all = 0;
float Vadc = 0;
//float Vbattery_car = 0;
uint16_t battery_percent_car = 0;
//mpu6050����
float pitch, roll, yaw;
short aacx, aacy, aacz;
short gyrox, gyroy, gyroz;
uint32_t uphill_count=0;
uint32_t downhill_count=0;

uint32_t TIM4_ms = 0;

uint16_t speed_ccr = 0;
uint16_t speed_con = 0;

uint16_t con1_ccr = 0;
uint16_t con2_ccr = 0;
uint32_t lorturn_cnt = 0;
//uint16_t turn_cnt = 0;
//systick����0��COUNTFLAGΪ1
//__STATIC_INLINE uint32_t LL_SYSTICK_IsActiveCounterFlag()
//{
//  return ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) == (SysTick_CTRL_COUNTFLAG_Msk));
//}

void delay_ms(uint32_t ms)
{
	for(int i=0;i<ms;i++)
		delay_us(1000);
}

void delay_us(uint32_t nus)
{
//	ͣ��	
//	uint32_t t0;
//	uint32_t m=HAL_GetTick();
//	uint32_t tms=SysTick->LOAD+1;	//24λ�ݼ�������,��װ��ֵ��72MHz��72000��Ĭ����1KHz��HAL_SYSTICK_Config();
//	__IO uint32_t u = tms - SysTick->VAL; 
//	if(LL_SYSTICK_IsActiveCounterFlag())
//	{
//		m=HAL_GetTick();
//		u=tms-SysTick->VAL;
//	}		
//	t0=(m*1000+(u*1000)/tms);
//	while((m*1000+(u*1000)/tms)-t0<us)
//		__NOP();
	
	uint32_t ticks;
	uint32_t told,tnow,tcnt=0;
	uint32_t reload=SysTick->LOAD;				//LOAD��ֵ	    	 
	ticks=nus*72; 						//��Ҫ�Ľ����� 
	told=SysTick->VAL;        				//�ս���ʱ�ļ�����ֵ
	while(1)
	{
		tnow=SysTick->VAL;	
		if(tnow!=told)
		{	    
			if(tnow<told)tcnt+=told-tnow;	//����ע��һ��SYSTICK��һ���ݼ��ļ������Ϳ�����.
			else tcnt+=reload-tnow+told;	    
			told=tnow;
			if(tcnt>=ticks)break;			//ʱ�䳬��/����Ҫ�ӳٵ�ʱ��,���˳�.
		}  
	};	
}
//������SDA��������SCL
void iic_start(void)
{
	iic_sda_out();     //sda�����
	SetIICSDA;SetIICSCL;	
	delay_us(2);
 	ClrIICSDA;//START:when CLK is high,DATA change form high to low 
	delay_us(2);
	ClrIICSCL;//ǯסI2C���ߣ�׼�����ͻ�������� 
}
//����SCL��SDA
void iic_stop(void)
{
	iic_sda_out();
	ClrIICSCL;ClrIICSDA;//STOP:when CLK is high DATA change form low to high
	delay_us(2);
	SetIICSCL;SetIICSDA;//����IIC���߽����ź�
	delay_us(2);
}
//1:ͨ�Ž���  0��Ӧ��ɹ�
uint8_t iic_wait_ack(void)
{
	uint8_t error_count=0;
	iic_sda_in();
	SetIICSDA;
	delay_us(2);
	SetIICSCL;
	delay_us(2);
	while(MPU_READ_SDA)
	{
		error_count++;
		if(error_count>250)
			return 1;
	}
	ClrIICSCL;
	return 0;
}
//����Ӧ��
void iic_ack(void)
{
	ClrIICSCL;
	iic_sda_out();
	ClrIICSDA; //0
	delay_us(2);
	SetIICSCL;
	delay_us(2);
	ClrIICSCL;
}
//��Ӧ��
void iic_Nack(void)
{
	ClrIICSCL;
	iic_sda_out();
	SetIICSDA; //1
	delay_us(2);
	SetIICSCL;
	delay_us(2);
	ClrIICSCL;
}
//�ȷ��͸�λ�����͵�λ MSB
void iic_send_byte(uint8_t txd)
{
	iic_sda_out();
	ClrIICSCL;
	for(int i=0;i<8;i++)
	{
		if(((txd&0x80)>>7)==1) //modify 20:57
			SetIICSDA;
		else
			ClrIICSDA;
		txd<<=1;
		SetIICSCL;
		delay_us(2);
		ClrIICSCL;
		delay_us(2);	
	}
}
//ack:1 ���ն���ֽڣ�0 ����1���ֽ�
uint8_t iic_read_byte(unsigned char ack)
{
	unsigned char receive=0;
	iic_sda_in();
	for(int i=0;i<8;i++)
	{
		ClrIICSCL;
		delay_us(2);
		SetIICSCL;
		receive<<=1;
		if(MPU_READ_SDA)receive++;
		delay_us(2);
	}
	if(!ack)
		iic_Nack();
	else
		iic_ack();
	return receive;

}
//PWM������ cnt:10000 10ms ���� 0~10000 0~5V 0~maxSpeed
//0~3900kmh	1.3v��������ѹ������1.3vû�ٶ�		��PD���ƣ������ۼƾ�̬���
void speed_control(uint16_t speed1, uint16_t speed2)
{
	//��ͣ���
	if(lora_message_r.drv_en == 0)
	{
		speed_pwm_out(0 , 0);
		return;
	}
	
	if(speed1==0&&speed2==0)
	{
		speed_pwm_out(0 , 0);
		return;
	}	
		
	uint16_t value1, value2;
			
	//Kp 2 ; Ki 21 ; Kd 0.05
	//���1
  pid1.SetSpeed = speed1;
  pid1.err = pid1.SetSpeed-pid1.ActualSpeed;
  //���������
	pid1.integral += pid1.err; 
	if(pid1.integral > 24768)
		pid1.integral = 24768;
	if(pid1.integral < -24768)
		pid1.integral = -24768;
  pid1.voltage = pid1.Kp*pid1.err+pid1.Ki*pid1.integral+(pid1.err-pid1.err_last)/pid1.Kd;
  pid1.err_last = pid1.err;

	//���2
	pid2.SetSpeed = speed2;
  pid2.err = pid2.SetSpeed-pid2.ActualSpeed;
	//���������
	pid2.integral += pid2.err;
	if(pid2.integral > 14768)
		pid2.integral = 14768;
	if(pid2.integral < -14768)
		pid2.integral = -14768;
  pid2.voltage = pid2.Kp*pid2.err+pid2.Ki*pid2.integral+(pid2.err-pid2.err_last)/pid2.Kd;
  pid2.err_last = pid2.err;
	
	
	speed_pwm_out(pid1.voltage, pid2.voltage);
	
}
//1.7v 1000mh  2.6v 3000mh	���ֻ��3v
//1.3v~2.3v��ÿ0.1v ����100rpm 	0~1000rpm   1.7v 436rpm  2.4v 1050rpm  2.5v 1150rpm 2.6v 1250rpm 2.7v 1300rpm 2.8v 1400rpm 2.9v 1450rpm 3.0 1540rpm
// 420 rpm/kmh	0.42
void speed_pwm_out(int pulse1, int pulse2)
{
	//���ٵĴ���  ����1.3v�����ת��
	//���ת��1460rpm��2.92v  ����3v
	if(pulse1 <= 0)
		pulse1 = 0;	
	else if(pulse1>=6000)
		pulse1=6000;
	
	if(pulse2 <= 0)
		pulse2 = 0;
	else if(pulse2>=6000)
		pulse2=6000;
	
	
	TIM2->CCR3=pulse1;
	TIM2->CCR4=pulse2; 
	
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
}
//prs: 3600-1, Mx_speed�Ŵ�1000��
void speed_sampling(void )
{
	//��⵽�������ź�
	if (__HAL_TIM_GET_FLAG(&htim3, TIM_FLAG_CC1) != RESET)
	{
		//__HAL_TIM_CLEAR_IT(&htim3, TIM_IT_CC1);
		//update1_flag = TRUE;
		update1_cnt = TIM4_ms;
		signal1_flag = TRUE;
		
		if(capture1_flag==FALSE)
		{
			M1_capture_value1=TIM3->CCR1;
			capture1_flag=TRUE;
		}
		else if(capture1_flag==TRUE)
		{
			M1_capture_value2=TIM3->CCR1;
			capture1_flag=FALSE;	
		}
		/*�����ٶ� 100pulse/s~~3.9Kmh*/
	
		/*
			10ms 1���� 3.9Kmh ��1s 100���壩
			value*0.1ms 1���� speed
			10ms��3.9=value��0.1ms��speed �ɷ�������ϵ
			speedֵ�Ŵ�1000��
		*/
		if(M1_capture_value2>M1_capture_value1)
		{
			M1_speed=390000/(M1_capture_value2-M1_capture_value1);
			//pid1.ActualSpeed=M1_speed;
		}	
		//�˲�
		speed_filter(&M1_speed);
		pid1.ActualSpeed=M1_speed;
	}
	
	if (__HAL_TIM_GET_FLAG(&htim3, TIM_FLAG_CC2) != RESET)
	{
		//update2_flag = TRUE;
		update2_cnt = TIM4_ms;
		signal2_flag = TRUE;
		if(capture2_flag==FALSE)
		{
			M2_capture_value1= TIM3->CCR2;
			capture2_flag=TRUE;
		}
		else if(capture2_flag==TRUE)
		{
			M2_capture_value2=TIM3->CCR2;
			capture2_flag=FALSE;			
		}
		
		if(M2_capture_value2>M2_capture_value1)
		{
			M2_speed=390000/(M2_capture_value2-M2_capture_value1);
			//pid2.ActualSpeed=M2_speed;
		}	
		//�˲�
		speed_filter(&M2_speed);
		pid2.ActualSpeed=M2_speed;
	}	
	
}

//�����˲���
void speed_filter(uint16_t* speed)
{
	//���ö�������ֵ
	if(*speed > 5000)
	{
		*speed = 4000;
		return;
	}
	
	if(*speed != speed_last)
	{
		//��ʼ������ʱ
		if(speed_last == 0)
		{
			speed_last = *speed;
			return;
		}
		//5�α仯�Ƴ�һ��
		count++;
		if(count>DAMP_CNT)
		{
			count = 0;
			speed_last = *speed;
		}
		else
			*speed = speed_last;
	}
//	else
//		count = 0;
	
	return;
//	if(*speed > speed_last)
//		*speed = alpha*speed_last + *speed*(1 - alpha); //һ�׵�ͨ�˲�
//	else
//		*speed = alpha*speed_last + *speed*(1 - alpha); //һ�׵�ͨ�˲�
}

void pid_value_init(void)
{	
	//����PID����
	pid1.Kp = 2;
	pid1.Ki = 21;
	pid1.Kd = 20;
  pid1.SetSpeed = 0;
  pid1.ActualSpeed = 0;
  pid1.err = 0;
  pid1.err_last = 0;
  pid1.integral = 0;
  pid1.voltage = 0;	
	
	pid2.Kp = 2;
	pid2.Ki = 21;
	pid2.Kd = 20;
	pid2.SetSpeed = 0;
  pid2.ActualSpeed = 0;
  pid2.err = 0;
  pid2.err_last = 0;
  pid2.integral = 0;
  pid2.voltage = 0;	
}

//speed:100~390
void PID_control(uint32_t speed1, uint32_t speed2)
{

	//���1
  pid1.SetSpeed = speed1;
  pid1.err = pid1.SetSpeed-pid1.ActualSpeed;
  pid1.integral += pid1.err;   
  pid1.voltage = pid1.Kp*pid1.err+pid1.Ki*pid1.integral;//+(pid1.err-pid1.err_last)/pid1.Kd;
  pid1.err_last = pid1.err;
    //pid.ActualSpeed = pid.voltage *1.0;
	//���2
	pid2.SetSpeed = speed2;
  pid2.err = pid2.SetSpeed-pid2.ActualSpeed;
  pid2.integral += pid2.err;   
  pid2.voltage = pid2.Kp*pid2.err+pid2.Ki*pid2.integral;//+(pid2.err-pid2.err_last)/pid2.Kd;
  pid2.err_last = pid2.err;
	
	speed_control(pid1.voltage, pid2.voltage);
  //return pid1.ActualSpeed;
}

void Is_car_stop()
{
	//̫��û�źţ��ٶȹ�0
	if(TIM4_ms - update1_cnt > 1000)
	{
		update1_cnt = 0;
		M1_speed = 0;
		speed_last = 0;
		signal1_flag = FALSE; 
	}
	
	if(TIM4_ms - update2_cnt > 1000)
	{	
		update2_cnt = 0;
		M2_speed = 0;
		speed_last = 0;
		signal2_flag = FALSE;
	}
}

uint8_t mpu6050_get_data()
{
	if(mpu_dmp_get_data(&pitch, &roll, &yaw)==0)  //����Ƕ�fifo�е����ݣ�����gyro, accel, quat(��̬����)
	{
		mpu6050_get_gyroscope(&gyrox, &gyroy, &gyroz); //����Ƕ��Ĵ����е�����
		mpu6050_get_accel(&aacx, &aacy, &aacz);
		return 1;
	}else
	
	return 0;
}

void lora_ranging()
{
	RangingDemoInitApplication(LORA_ENTITY);
	RangingDemoSetRangingParameters( 40u, DEMO_RNG_ADDR_1, DEMO_RNG_ANT_1, DEMO_RNG_UNIT_SEL_M );
  RangingDemoSetRadioParameters( LORA_SF6, LORA_BW_1600, LORA_CR_4_5, DEMO_CENTRAL_FREQ_PRESET2, DEMO_POWER_TX_MAX );
	Radio.Reset();
	
	RangingDemoStatus_t demoStatus;
  // Run the ranging demo.
  do{
		demoStatus = RangingDemoRun( );
  }while( demoStatus == DEMO_RANGING_RUNNING );

  // If master, display the ranging result.
  if( demoStatus != DEMO_RANGING_TERMINATED )
	{
    RangingDemoReset( );
  }
		
	demoResult = RangingDemoGetResult(); //���	
}

// V/20510 = Vadc/510  V = Vadc*20510/510
uint8_t get_car_battery(void)
{	
	if(!TIM4_flag)
		return 0;
	HAL_ADC_Start(&hadc1);
  HAL_ADC_PollForConversion(&hadc1, 10);    //�ȴ�ת����ɣ��ڶ���������ʾ��ʱʱ�䣬��λms        
	adc_value[adc_count] = HAL_ADC_GetValue(&hadc1);
	adc_count++;
	if(adc_count>=10)
	{
		adc_count=0;
		for(int i = 0;i < 10;i++)
			Vadc_all += adc_value[i];
		
		Vadc = Vadc_all/10;
		Vadc_all = 0;
		//Vbattery_car = 3.3*(Vadc/4096)*31;  //�����Ⱥ��б�Ҫ
		battery_percent_car = 100*(3.3*Vadc/4096*31+1.794-60)/(72-60);	//��ѹ����1.794v
		if(battery_percent_car>=100)
			battery_percent_car =99;
	}
	//return battery_percent_car;
}

//��ת��
void car_control_leftturn()
{
	M1_FZ;
	M2_ZZ;
	speed_control(800, 800);
}
//��ת��
void car_control_rightturn()
{
	M1_ZZ;
	M2_FZ;
	speed_control(800, 800);
}

//ͣ����
void car_control_pause(uint8_t back)
{
	//
	if(back>=56)
		return;
	//����
	pause_config();
	
}
//���˵�λ
void car_control_back(uint8_t lor, uint8_t uod)
{
	uint8_t offset;	
  speed_ccr = SPEED_L_CCR; //���ٺ���
	M1_FZ;
	M2_FZ;
	if(uod > 118)
	{
		pause_config();
	}
	else
	{
  	//0~255,	128 ֱ�ߺ���
  	if(lor>118&&lor<137)
		{
			speed_control(speed_ccr, speed_ccr);
		}
		//��ƫ�ƣ���ƫ�ƺ���
		else
		{
    	offset = lor>128?(lor-128):(128-lor);
    	
    	if(lor <= 118) //����
    	{
	
    		speed_control(speed_ccr-20*offset, speed_ccr); //�����ϵ��
    	}
    	// > 137
    	else	//����
    	{
    		speed_control(speed_ccr, speed_ccr-20*offset);
    	}
		}
	}
}

void car_control()
{

	//������λ
	if(lora_message_r.turn == 0)
	{
		M1_ZZ;
		M2_ZZ;
    //�Ӽ���
		uint8_t offset1, offset2;
		//0~255,	128 ��΢�ƶ�������
		if(lora_message_r.up_down>118&&lora_message_r.up_down<140)
			offset1 = 0;
		else
			offset1 = lora_message_r.up_down>128?(lora_message_r.up_down-128):(128-lora_message_r.up_down);
		
		//�޶���ʱ
		if(lora_message_r.left_right>118&&lora_message_r.left_right<140)
			offset2 = 0;
    //����ƫ��
		else
			offset2 = lora_message_r.left_right>128?(lora_message_r.left_right-128):(128-lora_message_r.left_right);
		
		
		//ֹͣ��λ
		if(lora_message_r.con_speed == 0)
		{
			speed_con = 0;
			speed_control(speed_con, speed_con);
		}
		
		//���ٵ�λ
		//lora_message_r.up_down��Χ: 32~250
		else if(lora_message_r.con_speed==1)
		{
			speed_ccr = SPEED_L_CCR;
			speed_con = 1000;			
			//���� 	���300 ~ 3100
			if(lora_message_r.up_down <= 118)
			{
				speed_con -= offset1*ACC_COEFICIENT;
				if(offset1*ACC_COEFICIENT>=1000)
					speed_con = 0;
			}
			//����  
			else	
				speed_con += offset1*ACC_COEFICIENT*3;
			
			
			//speed_con -= offset1*ACC_COEFICIENT;
//			if(offset2*TURN_COEFICIENT>=speed_con)
//			{

//				else if(lora_message_r.left_right<40)
//					speed_control(100, speed_con);
//				else if(lora_message_r.left_right>210)
//					speed_control(speed_con, 100);
////				else
////					speed_control(speed_con, speed_con)						
//			}				
			//ȫ���ɼ���
			if(lora_message_r.up_down<60)
				speed_control(speed_con, speed_con);
			
			else
			{
			  //��ת 	
			  if(lora_message_r.left_right <= 118)
			  {
					//��ֹ���
			  	speed_control(speed_con-TURN_COEFICIENT*offset2>0?(speed_con-TURN_COEFICIENT*offset2):100, speed_con);
			  }
			  //��ת  
			  else	
			  	speed_control(speed_con, speed_con-TURN_COEFICIENT*offset2>0?(speed_con-TURN_COEFICIENT*offset2):100);
			}
		}
		//���ٵ�λ
		else//(lora_message_r.con_speed == 3)
		{
			speed_ccr = SPEED_H_CCR;
			speed_con = 3000;
			//����  	���900 ~ 3700
			if(lora_message_r.up_down <= 118) 
			{
				speed_con -= offset1*ACC_COEFICIENT*3;
				if(offset1*ACC_COEFICIENT*3>=3000)
					speed_con = 0;
			}
			//����
			else	
				speed_con += offset1*ACC_COEFICIENT;			
			
			
//			if(offset2*TURN_COEFICIENT*3>=speed_con)
//			{
//				//ȫ���ɼ���
//				if(lora_message_r.up_down<60)
//					speed_control(speed_con, speed_con);
//				else if(lora_message_r.left_right<40)
//					speed_control(300, speed_con);
//				else if(lora_message_r.left_right>210)
//					speed_control(speed_con, 300);
//			}
			if(lora_message_r.up_down<60)
				speed_control(speed_con, speed_con);
			else
			{
		    //��ת  	
		    if(lora_message_r.left_right <= 118) 
		    {
		     	speed_control(speed_con-TURN_COEFICIENT*offset2*3>0?(speed_con-TURN_COEFICIENT*offset2*3):300, speed_con);
		    }
		    //��ת
		    else	
					speed_control(speed_con, speed_con-TURN_COEFICIENT*offset2*3?(speed_con-TURN_COEFICIENT*offset2*3):300);	
			}				 
		}

		//����״̬��־λΪ0	
		BACK_S_flag = FALSE;
	}
	//ת�䵵λ
	else
	{	
		//��ת��
		if(lora_message_r.left_right<=117)
		{	
			//��ʼ��ʱ
			if(!TURN_L_flag&&lorturn_cnt==0)
				lorturn_cnt = TIM4_ms;
      if(!TURN_L_flag&&TIM4_ms-lorturn_cnt>1000) //����1s�󣬽���ֹͣ״̬
      {
      	pause_config();		
				M1_FZ;
				M2_ZZ;				
      	if(TIM4_ms-lorturn_cnt>3000&&is_pause()) //ֹͣ2s�󣬽�������ת��״̬
      	{
					
      		TURN_L_flag = TRUE;
					TURN_R_flag = FALSE;
      	}					
      }
			
      if(TURN_L_flag)
      {
				lorturn_cnt = 0;
      	speed_con = 500;
      	speed_control(speed_con, speed_con);
      }   	
		}
		//��ת��
		else if(lora_message_r.left_right>=140)
		{
			//��ʼ��ʱ
			if(!TURN_R_flag&&lorturn_cnt==0)
				lorturn_cnt = TIM4_ms;
      if(!TURN_R_flag&&TIM4_ms-lorturn_cnt>1000) //����1s�󣬽���ֹͣ״̬
      {
				pause_config();
				M1_ZZ;
				M2_FZ;      						
      	if(TIM4_ms-lorturn_cnt>3000&&is_pause()) //ֹͣ2s�󣬽�������ת��״̬
      	{	
      		TURN_R_flag = TRUE;
					TURN_L_flag = FALSE;
      	}					
      }
			
      if(TURN_R_flag)
      {
				lorturn_cnt = 0;
      	speed_con = 500;
      	speed_control(speed_con, speed_con);
			}
		
		}
		else
		{
			pause_config();
			speed_con = 0;
			lorturn_cnt = 0;
			TURN_L_flag = FALSE;
			TURN_R_flag = FALSE;
			speed_control(speed_con, speed_con);
		}
	}	
}
void init_config()
{
	DRV_ENA1;	//ʹ��foc������
	DRV_ENA2;
	BRAKING1;	//�ƶ��򿪣��������
	BRAKING2;
	JTLED_ON;	
	JSLED_ON;
	LED_G;
}

void stop_config()
{
	DISBRAKING1;	//�ƶ�ʧ��
	DISBRAKING2;
	DRV_DISABLE1;
	DRV_DISABLE2;
	JTLED_OFF;	
	JSLED_ON;								
	LED_R;
	lora_message_r.turn = 0;
	lora_message_r.con_speed = 0;
	speed_control(0 , 0);
}

void pause_config()
{
	speed_con = 0;
	speed_control(0 ,0);
}

uint8_t is_pause()
{
	if(M1_speed<20 && M2_speed<20)
	{
		PAUSE_flag = TRUE;
		return 1;
	}
	else
	{
		PAUSE_flag = FALSE;
		return 0;
	}
}	

uint8_t lora_data_process(void)
{
	if(lora_message_r.serial_number != SERIAL_NUMBER)
			return -1;

	//��ͣ���
	if((connect_flag&&lora_message_r.drv_en==0)||!connect_flag)
	{
		stop_config();
		return 1;  //������������
	}
	
	if(connect_flag&&lora_message_r.drv_en==1)
		init_config();	
	
	//if(!connect_flag)
	//	return 1;
//	if((lora_message_r.drive_detail&0x04)==1)
//		stop_config();
//	else
//		init_config();
	//����ɲ��
	
	//�ٶ�Ϊ0
	if(lora_message_r.con_speed==0)
		speed_control(0 ,0);
	else
		car_control();
			
	//uint8_t up_down;	
	return 0;
}

void lora_data_package()
{

	get_car_battery();

	lora_message_t.battery=battery_percent_car;
	//�������ٶ�Ϊ��
	speed_sampling();
	Is_car_stop();
	lora_message_t.car_speed=(M1_speed+M2_speed)/2; //0~3900	
	//update1_flag = FALSE;
	//update2_flag = FALSE;
	//����
	lora_message_t.distance=(int)demoResult->RngDistance;
	
	//&pitch, &roll, &yaw
	if(mpu6050_get_data())
	{
		if(TIM4_flag)
		{
			if(pitch>20)
				uphill_count++;
			//�¶ȴ���20��
			else if(pitch<-20)
				downhill_count++;
			else
			{
				uphill_count=0;
				downhill_count=0;
			}
		}
		//����2s���� 00:ƽ· 01:���� 10:���� 
		if(uphill_count>=2000)			
			lora_message_t.status=(lora_message_t.status)|0x01;
		else if(downhill_count>=2000)
			lora_message_t.status=(lora_message_t.status)|0x02;
		else
			lora_message_t.status=(lora_message_t.status)&0xFC;
	}
}

