#ifndef USERFUN_H
#define USERFUN_H
#include "main.h"
#include "gpio.h"

#define SERIAL_NUMBER 100
//IO��������
#define iic_sda_in()  {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRL|=8<<28;} //PB7 ���� ����/����
#define iic_sda_out() {GPIOB->CRL&=0X0FFFFFFF;GPIOB->CRL|=3<<28;} //PB7 �������

//IO��������	 
#define SetIICSCL     	HAL_GPIO_WritePin(GPIOB, I2C_SCL_Pin, GPIO_PIN_SET)//���SCL
#define ClrIICSCL				HAL_GPIO_WritePin(GPIOB, I2C_SCL_Pin, GPIO_PIN_RESET)

#define SetIICSDA    		HAL_GPIO_WritePin(GPIOB, I2C_SDA_Pin, GPIO_PIN_SET)//���SDA	 
#define ClrIICSDA				HAL_GPIO_WritePin(GPIOB, I2C_SDA_Pin, GPIO_PIN_RESET)	 
#define MPU_READ_SDA   	HAL_GPIO_ReadPin(GPIOB, I2C_SDA_Pin)		//����SDA 


#define DRV_ENA1				HAL_GPIO_WritePin(DRV_ENA1_GPIO_Port, DRV_ENA1_Pin, GPIO_PIN_RESET)		
#define DRV_DISABLE1		HAL_GPIO_WritePin(DRV_ENA1_GPIO_Port, DRV_ENA1_Pin, GPIO_PIN_SET)	
#define DRV_ENA2				HAL_GPIO_WritePin(DRV_ENA2_GPIO_Port, DRV_ENA2_Pin, GPIO_PIN_RESET)	
#define DRV_DISABLE2		HAL_GPIO_WritePin(DRV_ENA2_GPIO_Port, DRV_ENA2_Pin, GPIO_PIN_SET)	

#define M1_ZZ						HAL_GPIO_WritePin(M1_ZF_GPIO_Port, M1_ZF_Pin, GPIO_PIN_RESET)	
#define M1_FZ						HAL_GPIO_WritePin(M1_ZF_GPIO_Port, M1_ZF_Pin, GPIO_PIN_SET)	
#define M2_ZZ						HAL_GPIO_WritePin(M2_ZF_GPIO_Port, M2_ZF_Pin, GPIO_PIN_RESET)	
#define M2_FZ						HAL_GPIO_WritePin(M2_ZF_GPIO_Port, M2_ZF_Pin, GPIO_PIN_SET)	

#define LED_B						HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_SET)	
#define LED_G						HAL_GPIO_WritePin(LED_G_GPIO_Port, LED_G_Pin, GPIO_PIN_SET)	
#define LED_R						HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_SET)	

#define BRAKING1				HAL_GPIO_WritePin(Braking1_GPIO_Port, Braking1_Pin, GPIO_PIN_SET)	
#define DISBRAKING1			HAL_GPIO_WritePin(Braking1_GPIO_Port, Braking1_Pin, GPIO_PIN_RESET)
#define BRAKING2				HAL_GPIO_WritePin(Braking2_GPIO_Port, Braking2_Pin, GPIO_PIN_SET)
#define DISBRAKING2			HAL_GPIO_WritePin(Braking2_GPIO_Port, Braking2_Pin, GPIO_PIN_RESET)

#define JSLED_ON				HAL_GPIO_WritePin(JSLED_GPIO_Port, JSLED_Pin, GPIO_PIN_SET)	
#define JSLED_OFF				HAL_GPIO_WritePin(JSLED_GPIO_Port, JSLED_Pin, GPIO_PIN_RESET)	
#define JTLED_ON				HAL_GPIO_WritePin(JTLED_GPIO_Port, JTLED_Pin, GPIO_PIN_SET)	
#define JTLED_OFF				HAL_GPIO_WritePin(JTLED_GPIO_Port, JTLED_Pin, GPIO_PIN_RESET)	

typedef  int BOOL;
#define TRUE 1
#define FALSE 0

//extern uint32_t M1_capture_value1;
//extern uint32_t M1_capture_value2;
//extern uint32_t M2_capture_value1;
//extern uint32_t M2_capture_value2;

//extern BOOL flag1_capture;
//extern BOOL flag2_capture;

void speed_control(uint16_t speed1, uint16_t speed2);//�ٶȵ���0~3900 
void speed_pwm_out(int pulse1, int pulse2);//0~10000��Ӧ0~5V
void speed_sampling(void );
void speed_filter(uint16_t* speed);

void delay_ms(uint32_t ms);
void delay_us(uint32_t us);

void iic_start(void);
void iic_stop(void);
uint8_t iic_wait_ack(void);
void iic_ack(void);
void iic_Nack(void);
void iic_send_byte(uint8_t txd);
uint8_t iic_read_byte(unsigned char ack);
uint8_t mpu6050_get_data(void);

uint8_t lora_pingpong(void);
uint8_t lora_data_process(void);
void lora_data_package(void);
void lora_ranging();
void car_control();
void car_control_lor(uint8_t lor);
void car_control_leftturn();
void car_control_rightturn();
void car_control_accdec(uint8_t lor);
void car_control_pause(uint8_t back);
void car_control_back(uint8_t lor, uint8_t uod);
uint8_t get_car_battery(void);
void stop_config(void);
void init_config(void);
void pause_config(void);
uint8_t is_pause(void);
void pid_value_init(void);
typedef struct {
	//uint8_t drv_en;	
	uint16_t car_speed;
	uint8_t serial_number;
	uint8_t battery;
	uint8_t status;
//	float pitch; //roll, yaw
//	float roll;
	uint8_t distance;
}lora_message_ts;

//drv_en:
typedef struct {
	uint8_t serial_number;	
	uint8_t left_right;
	uint8_t up_down;	
	uint8_t drv_en;
	uint8_t con_speed;
	uint8_t turn;
}lora_message_rs;

typedef struct{
  short SetSpeed;    //�趨�ٶ�
  short ActualSpeed;      //ʵ��ֵ
  short err;      //����ƫ��ֵ
  short err_last;       //��һ��ƫ��ֵ
  short Kp, Ki, Kd;     //p,i,dϵ��
  int voltage;    //��ѹֵ
  short integral;     //����ֵ,�����ֲ��ֵ��ۼ�ֵ
}pid_s;

#endif



