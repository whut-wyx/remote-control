#include "userFun.h"
#include "oled.h"
#include "radio.h"
#include "demoRanging.h"
#include "lora1280.h"
#include "adc.h"

#define LORA_ENTITY		MASTER   //0
static DemoResult_t  *demoResult;
double  rang = 0;
int tmp;

uint16_t adc1_c1_sampling_value_all = 0;
uint16_t adc1_c2_sampling_value_all = 0;
uint16_t adc1_c1_sampling_value = 2047;
uint16_t adc1_c2_sampling_value = 2047;
uint8_t adc1_count=0;
extern uint16_t adc1_value[2];
uint16_t rang_count=0;

uint32_t key1_count=0;
uint32_t key2_count=0;
uint32_t nkey_count=0;
uint32_t stop_count=0;
uint32_t turn_count=0;
//uint8_t stop_res_count=0;

uint16_t adc2_value[10] = {0};
uint8_t adc2_count = 0;
uint16_t Vadc2_all = 0;
uint16_t Vadc2 = 0;
float Vbattery = 0;
uint8_t battery_percent = 0;
//BOOL lora_send_flag;

extern BOOL TIM3_flag;
extern uint32_t TIM3_ms;
lora_message_ts lora_message_t;
lora_message_rs lora_message_r;

uint8_t speed_int = 0;
uint8_t speed_dem = 0;
//systick����0��COUNTFLAGΪ1
//__STATIC_INLINE uint32_t LL_SYSTICK_IsActiveCounterFlag()
//{
//  return ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) == (SysTick_CTRL_COUNTFLAG_Msk));
//}

void delay_ms(uint32_t ms)
{
	for(int i=0;i<ms;i++)
		delay_us(1000);
}

void delay_us(uint32_t nus)
{
//	uint32_t t0;
//	uint32_t m=HAL_GetTick();
//	uint32_t tms=SysTick->LOAD+1;	//24λ�ݼ�������,��װ��ֵ��72MHz��72000��Ĭ����1KHz��HAL_SYSTICK_Config();
//	__IO uint32_t u = tms - SysTick->VAL; 
//	if(LL_SYSTICK_IsActiveCounterFlag())
//	{
//		m=HAL_GetTick();
//		u=tms-SysTick->VAL;
//	}		
//	t0=(m*1000+(u*1000)/tms);
//	while((m*1000+(u*1000)/tms)-t0<us)
//		__NOP();
	
	uint32_t ticks;
	uint32_t told,tnow,tcnt=0;
	uint32_t reload=SysTick->LOAD;				//LOAD��ֵ	    	 
	ticks=nus*72; 						//��Ҫ�Ľ����� 
	told=SysTick->VAL;        				//�ս���ʱ�ļ�����ֵ
	while(1)
	{
		tnow=SysTick->VAL;	
		if(tnow!=told)
		{	    
			if(tnow<told)tcnt+=told-tnow;	//����ע��һ��SYSTICK��һ���ݼ��ļ������Ϳ�����.
			else tcnt+=reload-tnow+told;	    
			told=tnow;
			if(tcnt>=ticks)break;			//ʱ�䳬��/����Ҫ�ӳٵ�ʱ��,���˳�.
		}  
	};	
}
RangingDemoStatus_t demoStatus;
void lora_ranging()
{
	if(!TIM3_flag)
		return;
	rang_count++;
	//10s��һ�ξ���
	if(rang_count > 10)
	{
		rang_count=0;
		RangingDemoInitApplication(LORA_ENTITY);
		RangingDemoSetRangingParameters( 40u, DEMO_RNG_ADDR_1, DEMO_RNG_ANT_1, DEMO_RNG_UNIT_SEL_M );
		RangingDemoSetRadioParameters( LORA_SF6, LORA_BW_1600, LORA_CR_4_5, DEMO_CENTRAL_FREQ_PRESET2, DEMO_POWER_TX_MAX );
		Radio.Reset();
	
		//RangingDemoStatus_t demoStatus;
		// Run the ranging demo.
		do{
			demoStatus = RangingDemoRun( );
		}while( demoStatus == DEMO_RANGING_RUNNING );

		// If master, display the ranging result.
		if( demoStatus != DEMO_RANGING_TERMINATED )
		{
			RangingDemoReset( );
		}
		
		demoResult = RangingDemoGetResult(); //���	
		rang = demoResult->RngDistance;
	}
}

void lora_pingpong(void)
{
	//pingpong();


}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	//HAL_TIM_Base_Start_IT(&htim2);
	
	tmp++;
	SendNextPacketEvent();

}

void key_detect()
{
	//��Ϊ�ߵ�ƽ
	if(HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin)==SET && HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin)==SET)
	{
		if(lora_message_t.con_speed!=1&&nkey_count==0)
			nkey_count = TIM3_ms;
		if(TIM3_ms-nkey_count>=20)
		{
			nkey_count=0;
			lora_message_t.con_speed=1;	//�ٶ�1kmh
		}
	}	
	
	//���ټ��key1
	if(HAL_GPIO_ReadPin(KEY2_GPIO_Port, KEY2_Pin)==RESET)
	{
		if(lora_message_t.con_speed!=3&&key2_count==0)
			key2_count = TIM3_ms;
		if(TIM3_ms-key2_count>=20)
		{
			key2_count=0;
			lora_message_t.con_speed=3;	//�ٶ�3kmh
		}
	}
	else
		key2_count=0;
	//ֹͣ���key1
	if(HAL_GPIO_ReadPin(KEY1_GPIO_Port, KEY1_Pin)==RESET)
	{
		if(lora_message_t.con_speed!=0&&key1_count==0)
			key1_count = TIM3_ms;
		if(TIM3_ms - key1_count>=20)
		{
			key1_count=0;
			lora_message_t.con_speed=0;	//�ٶ�0kmh
		}
	}
	else
		key1_count=0;

	
	//��ͣ�������  ���鳣��
	if(HAL_GPIO_ReadPin(STOP_GPIO_Port, STOP_Pin)==RESET)
	{
		if(lora_message_t.drv_en!=1&&stop_count==0)
			stop_count = TIM3_ms;
		if(TIM3_ms - stop_count>=10)
		{
			stop_count=0;
			lora_message_t.drv_en=1; //ʹ��
			LED_G;
		}
	}
	else
	{
		stop_count=0;
		lora_message_t.drv_en=0; //ʧ��
		LED_R;
	}
	
	//ת�䰴�����  
	if(HAL_GPIO_ReadPin(TURN_GPIO_PORT, TURN_Pin)==RESET)
	{
		if(lora_message_t.turn!=1&&turn_count==0)
			turn_count = TIM3_ms;
		if(TIM3_ms - turn_count>=20)
		{
			turn_count=0;
			lora_message_t.turn=1; //ʹ��
			LED_B;
		}
	}
	else
	{
		turn_count=0;
		lora_message_t.turn=0; //ʧ��
		LED_R;
	}	
}

void adc1_value_sampling(void)
{
	//��ʼ�ɼ�
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc1_value, sizeof(adc1_value)/sizeof(uint16_t));
	
	if(!TIM3_flag)
		return;
	adc1_c1_sampling_value = adc1_value[0]; 
	adc1_c2_sampling_value = adc1_value[1]; 
	adc1_count++;
	
//	if(adc1_count >= 5)
//	{
//		adc1_count = 0;
//		adc1_c1_sampling_value = adc1_c1_sampling_value_all/5;
//		adc1_c2_sampling_value = adc1_c2_sampling_value_all/5;
//		
//		adc1_c1_sampling_value_all = 0;
//		adc1_c2_sampling_value_all = 0;
//	}	
//	//0~256
//	lora_message_t.left_right = (uint8_t)(adc1_c1_sampling_value/16);
//	lora_message_t.up_down = (uint8_t)(adc1_c2_sampling_value/16);
	
	lora_message_t.left_right = (uint8_t)(adc1_c1_sampling_value/16);
	lora_message_t.up_down = (uint8_t)(adc1_c2_sampling_value/16);
	//ҡ����΢�ƶ�������
//	if(lora_message_t.left_right > 118 && lora_message_t.left_right < 137 && lora_message_t.up_down > 118 && lora_message_t.up_down <137)
//		lora_send_flag = FALSE;	
}

//100%----4.2V
//90%-----4.06V
//80%-----3.98V
//70%-----3.92V
//60%-----3.87V
//50%-----3.82V
//40%-----3.79V
//30%-----3.77V
//20%-----3.74V
//10%-----3.68V
//5%------3.45V
//0%------3V
//10��Vbat/30=Vadc Vbat=3*Vadc Vadc 0~3.3V��Ӧ0~4097
uint8_t get_control_battery(void)
{
	if(!TIM3_flag)
		return 0;
	HAL_ADC_Start(&hadc2);
  HAL_ADC_PollForConversion(&hadc2, 10);    //�ȴ�ת����ɣ��ڶ���������ʾ��ʱʱ�䣬��λms        
	adc2_value[adc2_count] = HAL_ADC_GetValue(&hadc2);
	adc2_count++;
	if(adc2_count>=10)
	{
		adc2_count=0;
		for(int i = 0;i < 10;i++)
			Vadc2_all += adc2_value[i];
		
		Vadc2 = Vadc2_all/10;
		Vadc2_all = 0;
		Vbattery = 3*3.3f*Vadc2/4096;  //�����Ⱥ��б�Ҫ
		
		battery_percent = 100;
		//��������Ϊ����
		if(Vbattery<8.4f&&Vbattery>=8.12f)
			battery_percent = 90 + 10*(Vbattery-8.12f)/(8.4f-8.12f);
		if(Vbattery<8.12f&&Vbattery>=7.96f)
			battery_percent = 80 + 10*(Vbattery-7.96f)/(8.12f-7.96f);
		if(Vbattery<7.96f&&Vbattery>=7.84f)
			battery_percent = 70 + 10*(Vbattery-7.84f)/(7.96f-7.84f);		
		if(Vbattery<7.84f&&Vbattery>=7.74f)
			battery_percent = 60 + 10*(Vbattery-7.74f)/(7.84f-7.74f);
		if(Vbattery<7.74f&&Vbattery>=7.64f)
			battery_percent = 50 + 10*(Vbattery-7.64f)/(7.74f-7.64f);
		if(Vbattery<7.64f&&Vbattery>=7.58f)
			battery_percent = 40 + 10*(Vbattery-7.58f)/(7.64f-7.58f);
		if(Vbattery<7.58f&&Vbattery>=7.54f)
			battery_percent = 30 + 10*(Vbattery-7.54f)/(7.58f-7.54f);
		if(Vbattery<7.54f&&Vbattery>=7.48f)
			battery_percent = 20 + 10*(Vbattery-7.48f)/(7.54f-7.48f);
		if(Vbattery<7.48f&&Vbattery>=7.36f)
			battery_percent = 10 + 10*(Vbattery-7.36f)/(7.48f-7.36f);	
		if(Vbattery<7.36f&&Vbattery>=6.9f)
			battery_percent = 5 + 5*(Vbattery-6.9f)/(7.36f-6.9f);		
		if(Vbattery<6.9f&&Vbattery>6)
			battery_percent = 5*(Vbattery-6)/(6.9f-6);
		if(Vbattery <= 6)
			battery_percent = 0;
		
		if(battery_percent>=100)
			battery_percent = 99;
		
//			//��������Ϊ����
//		if(Vbattery<8.4f&&Vbattery>=8.12f)
//			battery_percent = 90 + 10*(Vbattery-4.2f)/(4.2f-4.06f);
//		if(Vbattery<4.06f&&Vbattery>=3.98f)
//			battery_percent = 80 + 10*(Vbattery-3.98f)/(4.06f-3.98f);
//		if(Vbattery<3.98f&&Vbattery>=3.92f)
//			battery_percent = 70 + 10*(Vbattery-3.92f)/(3.98f-3.92f);		
//		if(Vbattery<3.92f&&Vbattery>=3.87f)
//			battery_percent = 60 + 10*(Vbattery-3.87f)/(3.92f-3.87f);
//		if(Vbattery<3.87f&&Vbattery>=3.82f)
//			battery_percent = 50 + 10*(Vbattery-3.82f)/(3.87f-3.82f);
//		if(Vbattery<3.82f&&Vbattery>=3.79f)
//			battery_percent = 40 + 10*(Vbattery-3.79f)/(3.82f-3.79f);
//		if(Vbattery<3.79f&&Vbattery>=3.77f)
//			battery_percent = 30 + 10*(Vbattery-3.77f)/(3.79f-3.77f);
//		if(Vbattery<3.77f&&Vbattery>=3.74f)
//			battery_percent = 20 + 10*(Vbattery-3.74f)/(3.77f-3.74f);
//		if(Vbattery<3.74f&&Vbattery>=3.68f)
//			battery_percent = 10 + 10*(Vbattery-3.68f)/(3.74f-3.68f);	
//		if(Vbattery<3.68f&&Vbattery>=3.45f)
//			battery_percent = 5 + 5*(Vbattery-3.45f)/(3.68f-3.45f);		
//		if(Vbattery<3.45f&&Vbattery>=3)
//			battery_percent = 5*(Vbattery-3)/(3.45f-3);
	}
}

void lora_data_package()
{
	//lora_message_t.serial_number=SERIAL_NUMBER;
	//����
	//key1��⵽������
	key_detect();

}

// oled��Ļ��128*64����	
void oled_show(void)
{
		//��һ��
		GUI_ShowFont16(0 , 0, "״", 1); GUI_ShowFont16(16 , 0, "̬", 1);
		
		//�ڶ���
		GUI_ShowFont16(16 , 16, "��", 1); GUI_ShowFont16(32 , 16, "��", 1);
		GUI_ShowChar(48, 16, ':', 16, 1);
		speed_int = lora_message_r.car_speed/1000;
		speed_dem = lora_message_r.car_speed/100%10;
		GUI_ShowNum(55, 16, speed_int, 1, 16, 1);
		GUI_ShowChar(65, 16, '.', 16, 1);
		GUI_ShowNum(72, 16, speed_dem, 1, 16, 1);
		GUI_ShowString(82, 16, "km/h", 16, 1);
		
	  //������
		GUI_ShowFont16(0, 32, "��", 1);GUI_ShowFont16(16, 32, "��", 1);GUI_ShowFont16(32, 32, "��", 1);//GUI_ShowFont16(48, 32, "��", 1);
		//lora_message_r.battery = 9;
		GUI_ShowChar(48, 32, ':', 16, 1);GUI_ShowNum(60, 32, lora_message_r.battery, 2, 16, 1);
		GUI_ShowChar(80, 32, '%', 16, 1);
		//battery_percent = 99;
		
	  //������
		GUI_ShowFont16(0, 48, "��", 1);GUI_ShowFont16(16, 48, "��", 1);GUI_ShowFont16(32, 48, "��", 1);GUI_ShowFont16(48, 48, "��", 1);GUI_ShowFont16(64, 48, "��", 1);
		GUI_ShowChar(80, 48, ':', 16, 1);GUI_ShowNum(92, 48, battery_percent, 2, 16, 1);
		GUI_ShowChar(112, 48, '%', 16, 1);
}