/*!
 * \file      main.c
 *
 * \brief     main implementation
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2013-2018 Semtech
 *
 * \endcode
 *
 * \author    Semtech
 */
 
/* Includes ------------------------------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include "main.h"
#include "hw.h"
#include "radio.h"
#include "sx1280.h"
#include "lora1280.h"
#include "userFun.h"
/*!
 * \brief Used to display firmware version UART flow
 */

/*!
 * Select mode of operation for the Ping Ping application
 */

/*!
 * \brief Defines the nominal frequency
 */

/*!
 * \brief Defines the output power in dBm
 *
 * \remark The range of the output power is [-18..+13] dBm
 */

/*!
 * \brief Defines the buffer size, i.e. the payload size
 */

/*!
 * \brief Number of tick size steps for tx timeout
 */

/*!
 * \brief Number of tick size steps for rx timeout
 */

/*!
 * \brief Size of ticks (used for Tx and Rx timeout)
 */

/*!
 * \brief Defines the size of the token defining message type in the payload
 */


/*!
 * \brief Defines the states of the application
 */

/*!
 * \brief Function to be executed on Radio Tx Done event
// */
//void OnTxDone( void );

///*!
// * \brief Function to be executed on Radio Rx Done event
// */
//void OnRxDone( void );

///*!
// * \brief Function executed on Radio Tx Timeout event
// */
//void OnTxTimeout( void );

///*!
// * \brief Function executed on Radio Rx Timeout event
// */
//void OnRxTimeout( void );

///*!
// * \brief Function executed on Radio Rx Error event
// */
//void OnRxError( IrqErrorCode_t );


///*!
// * \brief Define the possible message type for this application
// */
////const uint8_t PingMsg[] = "PING";
////const uint8_t PongMsg[] = "PONG";

///*!
// * \brief All the callbacks are stored in a structure
// */
//RadioCallbacks_t Callbacks =
//{
//    &OnTxDone,        // txDone
//    &OnRxDone,        // rxDone
//    NULL,             // syncWordDone
//    NULL,             // headerDone
//    &OnTxTimeout,     // txTimeout
//    &OnRxTimeout,     // rxTimeout
//    &OnRxError,       // rxError
//    NULL,             // rangingDone
//    NULL,             // cadDone
//};
////AppStates_t AppState;
///*!
// * \brief The size of the buffer
// */
//uint8_t BufferSize = BUFFER_SIZE;

///*!
// * \brief The buffer
// */
//uint8_t Buffer[BUFFER_SIZE];

///*!
// * \brief Mask of IRQs to listen to in rx mode
// */
//uint16_t RxIrqMask = IRQ_RX_DONE | IRQ_RX_TX_TIMEOUT;

///*!
// * \brief Mask of IRQs to listen to in tx mode
// */
//uint16_t TxIrqMask = IRQ_TX_DONE | IRQ_RX_TX_TIMEOUT;

/*!
 * \brief The State of the application
 */
//AppStates_t AppState = APP_LOWPOWER;


//PacketParams_t packetParams;
//ModulationParams_t modulationParams;
//extern uint16_t lora_flag;
//void radio_init()
//{
//    //bool isMaster = true;    
//		SX1280HalReset();	
//		
//    //HwInit( );
//    HAL_Delay( 500 );                   // let DC/DC power ramp up

//    Radio.Init( &Callbacks );
//    Radio.SetRegulatorMode( USE_DCDC ); // Can also be set in LDO mode but consume more power
//    memset( &Buffer, 0x00, BufferSize );
//	
//    //printf( "\nPing Pong running in LORA mode\n\r" );
//    modulationParams.PacketType = PACKET_TYPE_LORA;
//    modulationParams.Params.LoRa.SpreadingFactor = LORA_SF12;
//    modulationParams.Params.LoRa.Bandwidth = LORA_BW_1600;
//    modulationParams.Params.LoRa.CodingRate = LORA_CR_LI_4_7;
//		
//    packetParams.PacketType = PACKET_TYPE_LORA;
//    packetParams.Params.LoRa.PreambleLength = 12;
//    packetParams.Params.LoRa.HeaderType = LORA_PACKET_VARIABLE_LENGTH;
//    packetParams.Params.LoRa.PayloadLength = BUFFER_SIZE;
//    packetParams.Params.LoRa.CrcMode = LORA_CRC_ON;
//    packetParams.Params.LoRa.InvertIQ = LORA_IQ_NORMAL;

//		
//    Radio.SetStandby( STDBY_RC );
//    Radio.SetPacketType( modulationParams.PacketType );
//    Radio.SetModulationParams( &modulationParams );
//    Radio.SetPacketParams( &packetParams );
//    Radio.SetRfFrequency( RF_FREQUENCY );
//    Radio.SetBufferBaseAddresses( 0x00, 0x00 );
//    Radio.SetTxParams( TX_OUTPUT_POWER, RADIO_RAMP_02_US );
//    
//		//SX1280SetInterruptMode();
//    SX1280SetPollingMode( );
//		

////    GpioWrite( LED_TX_PORT, LED_TX_PIN, 0 );
////    GpioWrite( LED_RX_PORT, LED_RX_PIN, 0 );

//    Radio.SetDioIrqParams( RxIrqMask, RxIrqMask, IRQ_RADIO_NONE, IRQ_RADIO_NONE );
//    Radio.SetRx( ( TickTime_t ) { RX_TIMEOUT_TICK_SIZE, RX_TIMEOUT_VALUE } );
//    //AppState = APP_LOWPOWER;

//}

//#define RADIO_RECEIVE_BUFFER_LENGTH 20
//uint8_t radio_receive_buffer[RADIO_RECEIVE_BUFFER_LENGTH] ;
//uint8_t radio_receive_bytes = 0 ;  //�����ֽ�������0,����ʾ�յ�������



//void OnRangingDone( IrqRangingCode_t val )
//{
//}

//void OnCadDone( bool channelActivityDetected )
//{
//}
//uint16_t	iSend, iRev;

//void Radio_Send( uint8_t *data, uint8_t length )
//{
//    Radio.SetDioIrqParams( TxIrqMask, TxIrqMask, IRQ_RADIO_NONE, IRQ_RADIO_NONE ) ; //����DIO1���ж�
//    Radio.SendPayload( data, 20, ( TickTime_t ) { RX_TIMEOUT_TICK_SIZE, TX_TIMEOUT_VALUE } ) ;
//}


////��������,ʧ�ܷ���0
//uint8_t Radio_SendData( uint8_t *buf, uint8_t size )
//{
//	uint8_t ret ;

//    Radio.SetDioIrqParams( TxIrqMask, TxIrqMask, IRQ_RADIO_NONE, IRQ_RADIO_NONE ) ; //����DIO1�ķ����ж�
//    Radio.SendPayload( buf, size, ( TickTime_t ) { RX_TIMEOUT_TICK_SIZE, TX_TIMEOUT_VALUE } ) ;    //��������
//    //AppState = APP_TX ;
//		delay_ms(10);
////    while ( AppState == APP_TX )    //�ȴ����ͽ��
////    {
////        delay_ms(1) ;
////    }

////    if ( AppState == APP_LOWPOWER ) //���ͳɹ�
////    {
////        ret = size ;    //���ط��͵��ֽ���
////        iSend ++ ;
////			//printf ("TF OK \r\n");
////    }
////    else    //���Ͳ��ɹ�,Ŀǰֻ�г�ʱһ�����
////    {
////        ret = 0 ;   //������
////        AppState = APP_LOWPOWER ;   //����쳣״̬
////    }

//	return ret ;
//}

////��������,�����ݷ���0
//uint8_t Radio_ReceiveData( uint8_t *buffer )
//{
//    uint8_t read_bytes = 0 ;

//    if ( BufferSize > 0 ) //�����������
//    {
//        memcpy( buffer, radio_receive_buffer, BufferSize ) ;
//        read_bytes = BufferSize ;
//        BufferSize = 0 ;  //�����ֽ�������,�Լ���������

//        iRev ++ ;
//    }

//    return read_bytes ;
//}

