#ifndef USERFUN_H
#define USERFUN_H
#include "main.h"

typedef  int BOOL;
#define TRUE 1
#define FALSE 0

#define SERIAL_NUMBER 100


#define LED_B				HAL_GPIO_WritePin(LED_B_GPIO_Port, LED_B_Pin, GPIO_PIN_SET)	
#define LED_G				HAL_GPIO_WritePin(LED_G_GPIO_Port, LED_G_Pin, GPIO_PIN_SET)	
#define LED_R				HAL_GPIO_WritePin(LED_R_GPIO_Port, LED_R_Pin, GPIO_PIN_SET)	

typedef struct {
	//uint8_t drv_en;
	uint16_t car_speed;
	uint8_t serial_number;
	uint8_t battery;
	uint8_t status;
//	float pitch; //roll, yaw
//	float roll;
	uint8_t distance;
}lora_message_rs;

typedef struct{		
	uint8_t serial_number;
	uint8_t left_right;
	uint8_t up_down;
	uint8_t drv_en;
	uint8_t con_speed;
	uint8_t turn;
}lora_message_ts;


void delay_ms(uint32_t ms);
void delay_us(uint32_t us);
void lora_ranging(void );
void lora_pingpong(void);
void adc1_value_sampling(void);
uint8_t get_control_battery(void);
void key_detect(void);
void lora_data_package();
void oled_show(void);
#endif
