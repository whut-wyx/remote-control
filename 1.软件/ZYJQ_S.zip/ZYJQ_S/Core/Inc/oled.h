#ifndef __OLED_H
#define __OLED_H			  	 
#include "main.h"

//--------------OLED��������---------------------
#define PAGE_SIZE    8
#define XLevelL		0x00
#define XLevelH		0x10
#define YLevel       0xB0
#define	Brightness	 0xFF 
#define WIDTH 	     128
#define HEIGHT 	     64	

//-------------д��������ݶ���-------------------
#define OLED_CMD     0	//д����
#define OLED_DATA    1	//д���� 
   						  
//-----------------OLED�˿ڶ���----------------
#define OLED_CS   CS_Pin    //Ƭѡ�ź�           PB1
#define OLED_RST  RST_Pin   //��λ�ź�           PB0
#define OLED_DC   DC_Pin		//���������ź�			 PC5

//-----------------OLED�˿ڲ�������---------------- 
#define OLED_CS_Clr  HAL_GPIO_WritePin(GPIOB, OLED_CS, GPIO_PIN_RESET)
#define OLED_CS_Set  HAL_GPIO_WritePin(GPIOB, OLED_CS, GPIO_PIN_SET)
					   
#define OLED_RST_Clr  HAL_GPIO_WritePin(GPIOB, OLED_RST, GPIO_PIN_RESET) //�͵�ƽ��λ
#define OLED_RST_Set  HAL_GPIO_WritePin(GPIOB, OLED_RST, GPIO_PIN_SET)
						 
#define OLED_DC_Clr   HAL_GPIO_WritePin(GPIOC, OLED_DC, GPIO_PIN_RESET) //����
#define OLED_DC_Set   HAL_GPIO_WritePin(GPIOC, OLED_DC, GPIO_PIN_SET) //����
//--------------SPI�������Ŷ���-----------------------
#define OLED_MOSI      MOSI_Pin  //OLED��SPIд�����ź�
#define OLED_CLK       SCK_Pin  //OLED��SPIʱ���ź�

//--------------SPI�˿ڲ�������---------------------
#define	OLED_MOSI_SET  	HAL_GPIO_WritePin(GPIOA, OLED_MOSI, GPIO_PIN_SET) 
#define	OLED_MOSI_CLR  	HAL_GPIO_WritePin(GPIOA, OLED_MOSI, GPIO_PIN_RESET) 
  
#define	OLED_CLK_SET  	HAL_GPIO_WritePin(GPIOA, OLED_CLK, GPIO_PIN_SET)    
#define	OLED_CLK_CLR  	HAL_GPIO_WritePin(GPIOA, OLED_CLK, GPIO_PIN_RESET)  

//OLED�����ú���
void oled_write_byte(uint8_t dat, uint8_t cmd);
void oled_display_on(void);
void oled_display_off(void);
void oled_reset(void);
void oled_init(void);
void OLED_Set_Pixel(unsigned char x, unsigned char y,unsigned char color);
void oled_display(void);
void oled_clear(void);   

//GUI����
void GUI_DrawPoint(uint8_t x, uint8_t y, uint8_t color);
void GUI_DrawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2,uint8_t color);
void GUI_DrawRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2,uint8_t color);
void GUI_FillRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2,uint8_t color);
void GUI_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t Char_Size,uint8_t mode);
void GUI_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t Size,uint8_t mode);
void GUI_ShowString(uint8_t x,uint8_t y,uint8_t *chr,uint8_t Char_Size,uint8_t mode);
void GUI_ShowFont16(uint8_t x,uint8_t y,uint8_t *s,uint8_t mode);
void GUI_ShowFont24(uint8_t x,uint8_t y,uint8_t *s,uint8_t mode);
void GUI_ShowFont32(uint8_t x,uint8_t y,uint8_t *s,uint8_t mode);
void GUI_ShowCHinese(uint8_t x,uint8_t y,uint8_t hsize,uint8_t *str,uint8_t mode);
void GUI_DrawBMP(uint8_t x,uint8_t y,uint8_t width, uint8_t height, uint8_t BMP[], uint8_t mode); 
#endif
