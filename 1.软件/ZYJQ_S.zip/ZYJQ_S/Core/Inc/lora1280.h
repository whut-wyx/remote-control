#ifndef LORA1280_H
#define LORA1280_H
#include "userFun.h"
#define FIRMWARE_VERSION    ( ( char* )"Firmware Version: 5709de2d" )
/*!
 * Select mode of operation for the Ping Ping application
 */
//#define MODE_BLE
#define MODE_LORA
//#define MODE_GFSK
//#define MODE_FLRC

//Ĭ�ϲ���ģʽ ��ʽ���ɱ䳤�ȣ���ͷģʽ
//preamble:12 head+crc:4/8 payload:20 crc:2




#define RF_BL_ADV_CHANNEL_38             			2426000000 // Hz
#define RF_BL_ADV_CHANNEL_0                     	2404000000 // Hz
#define RF_FREQUENCY                                RF_BL_ADV_CHANNEL_0 // Hz
#define TX_OUTPUT_POWER                             13
#define BUFFER_SIZE                                 10
#define TX_TIMEOUT_VALUE                            10000 // ms 
#define RX_TIMEOUT_VALUE                            1000 // ms
#define RX_TIMEOUT_TICK_SIZE                        RADIO_TICK_SIZE_1000_US
#define PINGPONGSIZE                                4


void radio_init();
uint8_t Radio_SendData( uint8_t *buf, uint8_t size );
uint8_t Radio_ReceiveData( uint8_t *buffer );
#endif

